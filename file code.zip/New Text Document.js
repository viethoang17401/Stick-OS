// --------------------
// JS CƠ BẢN CHO STICK OS
// --------------------

// Hiển thị thời gian thực
function updateClock() {
    const now = new Date();
    let h = String(now.getHours()).padStart(2, '0');
    let m = String(now.getMinutes()).padStart(2, '0');
    document.getElementById('clock').innerText = `${h}:${m}`;
}
setInterval(updateClock, 1000);
updateClock();

// Mở app
function openApp(appName) {
    const sections = document.querySelectorAll('section');
    sections.forEach(sec => sec.style.display = "none");

    if (appName === 'Chat') document.getElementById('chat').style.display = "block";
    if (appName === 'Store') document.getElementById('store').style.display = "block";
    if (appName === 'Music') document.getElementById('music').style.display = "block";
    if (appName === 'Pet') document.getElementById('pet-home').style.display = "block";
}

// Chuyển user
function switchUser(user) {
    alert("Đã chuyển sang user: " + user);
}
// --------------------
// CHAT APP GIẢ LẬP
// --------------------

// Gửi tin nhắn trong Chat App
function sendMessage() {
    const input = document.getElementById('chat-input');
    const msg = input.value.trim();
    if(msg === "") return;

    const box = document.getElementById('chat-box');
    const time = new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' });

    // Thêm tin nhắn vào chat-box
    const p = document.createElement('p');
    p.textContent = `[${time}] ${msg}`;
    box.appendChild(p);

    // Auto scroll xuống cuối
    box.scrollTop = box.scrollHeight;
    input.value = "";

    // Giả lập trả lời của hệ thống
    setTimeout(() => {
        const reply = document.createElement('p');
        reply.textContent = `[${time}] 🤖 Hệ thống: Tin nhắn của bạn đã được nhận!`;
        reply.style.color = "green";
        box.appendChild(reply);
        box.scrollTop = box.scrollHeight;
    }, 1000);
}

// Enter cũng gửi tin nhắn
document.addEventListener('DOMContentLoaded', () => {
    const input = document.getElementById('chat-input');
    input.addEventListener('keypress', (e) => {
        if(e.key === 'Enter') {
            sendMessage();
        }
    });
});
// --------------------
// PET HOẠT ĐỘNG
// --------------------

// Lấy danh sách pet
const pets = document.querySelectorAll('.pet img');
const petLog = document.getElementById('pet-log');

// Hàm log hành động pet
function logPetAction(text) {
    const time = new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' });
    const p = document.createElement('p');
    p.textContent = `[${time}] ${text}`;
    petLog.appendChild(p);
    petLog.scrollTop = petLog.scrollHeight;
}

// Pet nghịch icon
function petPlayIcon() {
    const icons = document.querySelectorAll('.app-icon');
    if(icons.length === 0) return;

    const randomIcon = icons[Math.floor(Math.random() * icons.length)];
    randomIcon.classList.add('rung');

    logPetAction("Một con pet vừa nghịch icon " + randomIcon.textContent + " 🐾");

    setTimeout(() => {
        randomIcon.classList.remove('rung');
    }, 400);
}

// Pet thỉnh thoảng tự động hoạt động
setInterval(() => {
    // 50% cơ hội pet làm gì đó
    if(Math.random() > 0.5) {
        const actions = [
            "Mun liếm icon và để lại dấu chân 🐾",
            "Miu nhảy lên bàn phím 💻",
            "LU với Khoai đang cắn cáp sạc ⚡",
            "Bunny Chan đang ăn cà rốt 🥕",
            "IP đang đọc tiểu thuyết trinh thám 📖"
        ];
        const action = actions[Math.floor(Math.random() * actions.length)];
        logPetAction(action);

        // 30% cơ hội rung icon
        if(Math.random() > 0.7) petPlayIcon();
    }
}, 7000); // Mỗi 7 giây check 1 lần
// --------------------
// STICK STORE & VÍ PET
// --------------------

// Ví của từng user/pet (VNĐ ảo)
let petWallet = {
    "Mun": 100000,
    "Miu": 50000,
    "LU": 20000,
    "Khoai": 20000,
    "Bunny Chan": 30000,
    "IP": 80000
};

// Log mua đồ trong Store
function buyItem(petName, itemName, price) {
    if(petWallet[petName] === undefined) {
        logPetAction(`❌ Không tìm thấy ví cho ${petName}`);
        return;
    }

    if(petWallet[petName] < price) {
        logPetAction(`💸 ${petName} không đủ tiền để mua ${itemName}!`);
        return;
    }

    petWallet[petName] -= price;
    logPetAction(`🛒 ${petName} vừa mua ${itemName} với giá ${price.toLocaleString()} VNĐ. Số dư còn: ${petWallet[petName].toLocaleString()} VNĐ`);
}

// Demo một số nút mua trong Store
document.addEventListener('DOMContentLoaded', () => {
    const storeItems = document.querySelectorAll('#store li');
    storeItems.forEach(item => {
        item.addEventListener('click', () => {
            // Giả lập: Mun là người mua
            buyItem("Mun", item.textContent, Math.floor(Math.random()*10000+5000));
        });
    });
});

// Chia tiền cho pet
function giveMoney(petName, amount) {
    if(petWallet[petName] === undefined) return;
    petWallet[petName] += amount;
    logPetAction(`💰 ${petName} nhận ${amount.toLocaleString()} VNĐ! Số dư hiện tại: ${petWallet[petName].toLocaleString()} VNĐ`);
}
// --------------------
// PET SỨC KHỎE & SỰ KIỆN ĐẶC BIỆT
// --------------------

let petHealth = {
    "Mun": 100,
    "Miu": 100,
    "LU": 100,
    "Khoai": 100,
    "Bunny Chan": 100,
    "IP": 100
};

// Kiểm tra sức khỏe pet theo thời gian
setInterval(() => {
    for (let pet in petHealth) {
        // 5% khả năng pet bị ốm mỗi 30s
        if (Math.random() < 0.05) {
            petHealth[pet] -= 20;
            logPetAction(`⚠️ ${pet} bị ốm! Sức khỏe còn ${petHealth[pet]}%`);
            if (petHealth[pet] <= 0) {
                logPetAction(`💀 ${pet} đã bay màu!`);
            }
        }
    }
}, 30000); // 30s kiểm tra 1 lần

// Tắm cho pet (5 phút = 5s demo)
function bathPet(petName) {
    logPetAction(`🛁 Đang tắm cho ${petName}...`);
    setTimeout(() => {
        // 20% khả năng tắm lâu bị ốm
        if(Math.random() < 0.2) {
            petHealth[petName] -= 10;
            logPetAction(`🤧 ${petName} tắm lâu bị cảm nhẹ!`);
        } else {
            petHealth[petName] = Math.min(100, petHealth[petName] + 20);
            logPetAction(`✨ ${petName} đã sạch sẽ và khỏe hơn!`);
        }
    }, 5000);
}

// Sự kiện sinh nhật pet
function checkBirthday(petName, birthday) {
    const now = new Date();
    const today = `${now.getDate()}/${now.getMonth()+1}`;
    if(today === birthday) {
        logPetAction(`🎂 Hôm nay là sinh nhật ${petName}! Bánh chà bông xuất hiện!`);
        giveMoney(petName, 10000); // thưởng sinh nhật
    }
}

// Hồi sinh pet bằng sách ma thuật
function revivePet(petName) {
    if(petHealth[petName] > 0) {
        logPetAction(`❌ ${petName} chưa chết nên không cần hồi sinh!`);
        return;
    }
    petHealth[petName] = 50;
    logPetAction(`📖 ${petName} đã được hồi sinh bằng sách ma thuật!`);
}

// Demo check sinh nhật cho Mun & Miu (các pet khác cậu thêm tương tự)
setInterval(() => {
    checkBirthday("Mun","1/8");
    checkBirthday("Miu","2/8");
}, 60000); // 1 phút check 1 lần
